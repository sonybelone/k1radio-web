<<<<<<<< Update Guide >>>>>>>>>>>
Immediate Older Version: 1.1.0
Current Version: 1.2.0
Feature Update:
1. Optimization & Bug Fixing
2. Installer & CDN Update


Please Use Those Command On Your Terminal To Update Full System
1. To Run Project Please Run This Command On Your Terminal
    composer update && composer dump-autoload 
2. To Update Feature
    php artisan db:seed --class=Database\\Seeders\\UpdateFeatureSeeder
