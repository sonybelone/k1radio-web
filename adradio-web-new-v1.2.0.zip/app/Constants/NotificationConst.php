<?php

namespace App\Constants;

class NotificationConst {
    const SIDE_NAV = "SIDE_NAV";
}