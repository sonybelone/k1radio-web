<?php

namespace App\Constants;

class AdminRoleConst {
    const SUPER_ADMIN = "Super Admin";
    const DASHBOARD = "admin.dashboard"; 
}