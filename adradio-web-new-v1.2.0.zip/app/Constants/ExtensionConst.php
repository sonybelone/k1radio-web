<?php

namespace App\Constants;

class ExtensionConst {
    const TAWK_TO = "Tawk To";
    const TAWK_TO_SLUG = "tawk-to";
    const TAWK_TO_PROPERTY_ID = "property_id";
    const TAWK_TO_WIDGET_ID = "widget_id";
}