<div id="teamItem-add" class="mfp-hide large">
    <div class="modal-data">
        <div class="modal-header px-0">
            <h5 class="modal-title">{{ __("Add Team Social Icon") }}</h5>
        </div>
        <div class="modal-form-data">
            <form class="modal-form" method="POST" action="{{ setRoute('admin.setup.sections.section.item.store',$slug) }}" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="type" value="noLang">
                <input type="hidden" name="target" value="{{ $id }}">
                <div class="row mb-10-none mt-3">
                    <div class="form-group">
                        @include('admin.components.form.input',[
                            'label'     =>__("Link").'*',
                            'name'      => "link",
                            'value'     => old("link")
                        ])
                    </div>
                    <div class="form-group">
                        @include('admin.components.form.input-file',[
                            'label'             => __("Icon Image"),
                            'name'              => "icon_image",
                            'class'             => "file-holder",
                            'old_files_path'    => files_asset_path("site-section"),
                            'old_files'         => old("old_image"),
                        ])
                    </div>
                    <div class="col-xl-12 col-lg-12 form-group d-flex align-items-center justify-content-between mt-4">
                        <button type="button" class="btn btn--danger modal-close">{{ __("Cancel") }}</button>
                        <button type="submit" class="btn btn--base">{{ __("Add") }}</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
