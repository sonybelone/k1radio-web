<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Password Reset</title>
</head>
<body>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor iusto ratione praesentium enim in suscipit, adipisci sed nesciunt eum exercitationem quas deserunt dolorem quisquam doloremque rem consequatur quo nihil necessitatibus repudiandae eius quibusdam voluptatum tenetur quis. Nesciunt ea est sint laboriosam vel unde magni reiciendis perspiciatis accusamus, doloremque alias quis ab nulla. Fugiat pariatur natus animi. Saepe aspernatur facere perferendis eos pariatur assumenda minima illo sed a! Consequuntur vero error sunt nihil distinctio atque dolorem corrupti, fugit illo. Fugiat perspiciatis officia incidunt tempora voluptas inventore deleniti at. In maiores deserunt minima laborum ut tempore rerum quos voluptas vel! Iure in reiciendis laboriosam consequuntur a odio quia maxime. Amet maxime atque repellat perspiciatis voluptates dolore, laborum unde esse, minus delectus molestiae modi totam, necessitatibus sunt? Error, tenetur maxime quasi soluta molestias veniam natus quo facilis facere itaque dolores voluptatum explicabo magnam necessitatibus, totam incidunt voluptate consequatur! Et reprehenderit magni, aliquam ad ex consequatur laudantium, porro voluptatibus eum tenetur incidunt architecto beatae tempora, sint sunt omnis expedita doloribus quaerat earum dolorum nam iste fuga? Similique cumque sunt ea nostrum, officiis ipsa veniam error perferendis dignissimos ipsam necessitatibus aut mollitia quibusdam sequi laboriosam, odio doloremque est qui cum, in explicabo reprehenderit voluptate. Fugit.

    <a href="{{ $url ?? "javascript:void(0)" }}">Click</a>
</body>
</html>